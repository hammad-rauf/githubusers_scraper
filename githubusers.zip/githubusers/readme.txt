
copy id number from id.txt

enter on terminal = scrapy crawl githubusers -o {id}.json


do not temper files:
			id.txt	
			link.txt
